﻿namespace GradeBook.Enums
{
    public enum GradeBookType
    {
        Standard,
        Ranked,
        ESNU,
        OneToFour,
        SixPoint
    }
}
